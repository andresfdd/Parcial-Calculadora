package com.example.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.lang.Math;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TextView nums;
    float num1, num2;
    String signo;
    boolean sign;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nums = (TextView) findViewById(R.id.numeros);
        sign = true;
    }

    public void uno(View view) {
        nums.setText(nums.getText() + "1");
        sign = false;
    }

    public void dos(View view) {
        nums.setText(nums.getText() + "2");
        sign = false;
    }

    public void tres(View view) {
        nums.setText(nums.getText() + "3");
        sign = false;
    }

    public void cuatro(View view) {
        nums.setText(nums.getText() + "4");
        sign = false;
    }

    public void cinco(View view) {
        nums.setText(nums.getText() + "5");
        sign = false;
    }

    public void seis(View view) {
        nums.setText(nums.getText() + "6");
        sign = false;
    }

    public void siete(View view) {
        nums.setText(nums.getText() + "7");
        sign = false;
    }

    public void ocho(View view) {
        nums.setText(nums.getText() + "8");
        sign = false;
    }

    public void nueve(View view) {
        nums.setText(nums.getText() + "9");
        sign = false;
    }

    public void cero(View view) {
        nums.setText(nums.getText() + "0");
        sign = false;
    }
    public void punto(View view) {
        nums.setText(nums.getText() + ".");
        sign = true;
    }

    public void limpiar(View view) {
        nums.setText("");
    }

    public void dividir(View view) {
        if (sign == false) {
            String valor = nums.getText().toString();
            num1 = Float.parseFloat(valor);
            signo = "/";
            nums.setText("");
            sign = true;
        } else if(sign == true)
            nums.setText("Primero ingrese un número");
    }

    public void multiplicar(View view) {
        if (sign == false) {
            String valor = nums.getText().toString();
            num1 = Float.parseFloat(valor);
            signo = "*";
            nums.setText("");
            sign = true;
        }
        else if(sign == true)
            nums.setText("Primero ingrese un número");
    }

    public void restar(View view) {
        if (sign == true) {
            nums.setText("-");
        } else {
            String valor = nums.getText().toString();
            num1 = Float.parseFloat(valor);
            signo = "-";
            nums.setText("");
            sign = true;
        }
    }

    public void sumar(View view) {
        if (sign == false) {
            String valor = nums.getText().toString();
            num1 = Float.parseFloat(valor);
            signo = "+";
            nums.setText("");
            sign = true;
        }
        else
            nums.setText("Primero ingrese un número");
    }

    public void potencia(View view) {
        if (sign == false) {
            String valor = nums.getText().toString();
            num1 = Float.parseFloat(valor);
            signo = "^";
            nums.setText("");
            sign = true;
        }else
            nums.setText("Primero ingrese un número");
    }

    public void raiz(View view){
        nums.setText("√");
        signo = "√";
        nums.setText("");
    }

    public void operar(View view) {
        String valor = nums.getText().toString();
        num2 = Float.parseFloat(valor);
        switch (signo) {
            case "+":
                float res = num1 + num2;
                nums.setText(String.valueOf(res));
                break;
            case "-":
                res = num1 - num2;
                nums.setText(String.valueOf(res));
                break;
            case "*":
                res = num1 * num2;
                nums.setText(String.valueOf(res));
                break;
            case "/":
                if (num2 != 0) {
                    res = num1 / num2;
                    nums.setText(String.valueOf(res));
                } else
                    nums.setText("Operación imposible");
                break;
            case "^":
                res = (float) Math.pow(num1, num2);
                nums.setText(String.valueOf(res));
                break;
            case "√":
                num1 = Float.parseFloat(nums.getText().toString());
                if (num1 >= 0) {
                    res = (float) Math.sqrt(num1);
                    nums.setText(String.valueOf(res));
                }else
                    nums.setText("");
        }
    }

    public void eliminar(View view) {
        String numeros = nums.getText().toString();
        numeros = numeros.substring(0, numeros.length() - 1);
        nums.setText(numeros);
    }
}
